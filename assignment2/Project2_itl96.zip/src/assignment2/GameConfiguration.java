/* EE422C Assignment #2
 * Isaac Lee
 * itl96
 */

package assignment2;

public class GameConfiguration {
    public static final int guessNumber = 12;  //guess numbers
    public static final String[] colors = {"B","G","O","P","R","Y"};  //colors involved
    public static final int pegNumber = 4;  //pegs involved
}
